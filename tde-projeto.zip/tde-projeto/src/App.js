
import './App.css';
import UserInfo from './components/UserInfo';

const list1 = [
  {
    name: 'Leonardo',
    birthday: '01/01/2000',
    email: 'leonardo@email.com'
  },
  {
    name: 'Leon',
    birthday: '02/02/2000',
    email: 'leon@email.com'
  },
  {
    name: 'Giovanne',
    birthday: '08/08/1999',
    email: 'giovanne@email.com'
  }]

function App() {
  return (
    <div className="App">
      <div className>
        <UserInfo items={list1} />
      </div>
    </div>
  );
}

export default App;
