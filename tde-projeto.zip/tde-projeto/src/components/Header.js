import './Header.css'

const Header = () => {
    return (
        <header>    
            Header
        </header>
    );
}

export default Header;